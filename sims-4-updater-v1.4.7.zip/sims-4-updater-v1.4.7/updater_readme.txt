Sims 4 Updater - GUI tool for updating/repairing your The Sims 4 game
made by anadius

CS RIN thread: https://cs.rin.ru/forum/viewtopic.php?f=29&t=102519

=======================================================================================

FAQ:

    Q: Updater doesn't run, I get some error message, what should I do?
    A: First of all Sims 4 Updater is 64-bit only, so make sure your Windows
       is 64-bit too. It's written in Python 3.11 and they dropped Windows 7
       support in 3.9, so if you have Windows 7 - update it to 8 or newer.
       And lastly make sure you have VC Redist 2015-2022 x64
       ( https://support.microsoft.com/en-us/help/2977003/the-latest-supported-visual-c-downloads )
       installed and that your anti-virus doesn't block it.
       There's a hack to make it run on Windows 7 but don't ask me for help with it.
       ( https://github.com/nalexandru/api-ms-win-core-path-HACK )

    Q: My anti-virus says Updater is a virus, should I be concerned?
    A: Sims 4 Updater is written in Python and turned into exe with
       PyInstaller. It is a common issue that some anti-viruses mark it as
       a virus because of how it's made instead of checking what it does.
       ( https://github.com/pyinstaller/pyinstaller/issues/6754 )
       There's a source code audit by administrator of CS RIN forum posted
       in the second post of the Updater thread.
       ( https://cs.rin.ru/forum/viewtopic.php?p=2025856#p2025856 )
       I've been making stuff for The Sims 4 since 2018:
       ( https://cs.rin.ru/forum/viewtopic.php?p=1780388#p1780388 )
       If you don't trust the Updater - don't use any other of my tools either.
       Online crack that most repackers use is also made by me. :)

Run the Updater for full readme file.
